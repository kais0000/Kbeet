Thanks for downloading this template!

Template Name: Online Betting
Template URL: https://themeslay.com/freebie/online-betting-bootstrap-website-template
Author: Themeslay
License: https://themeslay.com/license/
